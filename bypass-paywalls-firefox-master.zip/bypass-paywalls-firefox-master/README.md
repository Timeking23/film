# Bypass Paywalls for Firefox
### This repo has been merged with the Chrome repo and moved to: https://github.com/iamadamdev/bypass-paywalls-chrome
